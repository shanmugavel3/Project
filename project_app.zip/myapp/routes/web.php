<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuthController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\companycontroller;
use App\Http\Controllers\UserController;
use App\Http\Controllers\displayController;
use App\Http\Controllers\FullCalanderController;
use App\Mail\MyTestEmail;
use Illuminate\Support\Facades\Mail;

// students
Route::get('students',[StudentController::class,'index'])->name('students');
Route::post('/registerdetails',[StudentController::class,'registeruser'])->name('registerdetails');
// Route::post('students',[StudentController::class,'index'])->name('students');

Route::get('/login',[CustomAuthController::class,'login']);
Route::get('/registration',[CustomAuthController::class,'registration']);

Route::post('/register-user',[CustomAuthController::class,'registeruser'])->name('registeruser');
Route::post('/login-user',[CustomAuthController::class,'loginuser'])->name('loginuser');

Route::get('/dashboard',[CustomAuthController::class,'dashboard']);
Route::get('/logout',[CustomAuthController::class,'logout']);




// Route::get('userdata',[companycontroller::class,'index']);
// Route::post('userdata',[companycontroller::class,'addData']);
// Route::get('userdata',[companycontroller::class,'list']);

// Route::get('data',[displayController::class,'filter']);



Route::get('company',[companycontroller::class,'index']);
Route::post('drive',[companycontroller::class,'addData']);
Route::get('drive',[companycontroller::class,'list']);
Route::get('course',[displayController::class,'filter']);





Route::get('/testroute', function() {
    $name = "Funny Coder";

//The email sending is done using the to method on the Mail facade
    Mail::to('tamilselvamcr72001@gmail.com')->send(new MyTestEmail($name));
});





Route::get('fullcalender', [FullCalanderController::class, 'index']);
Route::post('fullcalenderAjax', [FullCalanderController::class, 'ajax']);

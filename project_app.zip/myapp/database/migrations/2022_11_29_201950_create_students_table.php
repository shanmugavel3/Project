
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string("name");
            $table->string("gender");
            $table->string('regno');
            $table->date("dob");
            $table->string("email");
            $table->string("phnno");
            $table->string("class");
            $table->string("batch");
            $table->string("degree");
            $table->longText('doorno');
            $table->longText('street');
            $table->longText('city');
            $table->longText('district');
            $table->string('pincode');
            $table->longText('state');
            $table->string("sslcname");
            $table->integer("sslc");
            $table->string("hscname");
            $table->integer('hsc');
            $table->integer('ug');
            $table->string("ugname");
            $table->string("image");
            $table->string("resume");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
};

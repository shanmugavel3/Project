<?php

namespace App\Http\Controllers;

use DB;

use App\Models\Student;
use Illuminate\Http\Request;
use App\Models\post;

class companycontroller extends Controller
{
 public function index(){
    // return view('admin.welcome');
    return view('admin.company');
 }

   public function addData(Request $req)
{
    $post = new post;
    $post->cname =$req->cname;
    $post->clocation =$req->clocation;
    $post->cdetail =$req->cdetail;
    $post->clink =$req->clink;
    $post->cdate =$req->cdate;
    $post->save();
    return  redirect('drive');
}

     public function list()
     {
        $data = post::all();
        // return view('admin.welcome',['data'=>$data]);
        return view('admin.drive',['data'=>$data]);

     }

//      public function filter(Request $request){
//       $table = DB::table('students');
//       $table1 = DB::table('students')->get();
//       $table2 = DB::table('filters')->get();

//       if($request->name!=null){

//          $table = $table->where('filters.class','like',$request->name);

//       }
//             $table =$table
//             ->join('filters','filters.class','=','students.class')
//             ->select('filters.class as course','students.name as name','students.batch as batch')
//             ->get();

//             return view('admin.course',['user'=>$table1,'table'=>$table2]);

// }
}

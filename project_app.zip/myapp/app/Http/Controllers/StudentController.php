<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\Models\Student;

use Hash;

class StudentController extends Controller
{
    public function index(){
        return view('student.index');
    }


    public function registeruser(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'regno'=>'required',
            'gender'=>'required',
            'email'=>'required|email|unique:students',
            "dob"=>'required|date',
            "phnno"=>'required',
            'class'=>'required',
            'batch'=>'required',
            "sslcname"=>'required',
            "sslc"=>'required',
            "hscname"=>'required',
            'hsc'=>'required',
            'degree'=>'required',
            'ug'=>'required',
            "ugname"=>'required',
            "image"=>'required',
            "resume"=>'required',
            'doorno'=>'required|numeric',
            'street'=>'required',
            'city'=>'required',
            'district'=>'required',
            'state'=>'required',
            'pincode'=>'required|numeric'
        ]);


        // if($request->input('image'))
        // {
        //     $image_name = $request->file('image')->getClientOriginalName();
        //     $filename = pathinfo($image_name,PATHINFO_FILENAME);
        //     $image_ext = $request->file('image')->getClientOriginalExtension();
        //     $fileNameToStore = time().'.'.$image_ext;
        //     $path =  $request->file('image')->storeAs('public/product',$fileNameToStore);
        // }
        // else{
        //     $fileNameToStore = 'no';
        // }

//         if($request->hasFile('image'))
//    {
//        $image_name = $request->file('image')->getClientOriginalName();
//        $filename = pathinfo($image_name,PATHINFO_FILENAME);
//        $image_ext = $request->file('image')->getClientOriginalExtension();
//        $fileNameToStore = time().'.'.$image_ext;
//     //    $destinationPath = public_path('images\product');
//        $path =  $request-file('image')->storeAs('public/images/',$fileNameToStore);

//    }
//    else{
//        $fileNameToStore = 'noimage.jpg';
//    }



        $student = new Student();
        $student->name = $request->input('name');
        $student->gender = $request->input('gender');
        $student->dob = $request->input('dob');
        $student->regno = $request->input('regno');
        $student->class = $request->input('class');
        $student->email = $request->input('email');
        $student->phnno = $request->input('phnno');
        $student->batch = $request->input('batch');
        $student->sslcname = $request->input('sslcname');
        $student->sslc = $request->input('sslc');
        $student->hscname = $request->input('hscname');
        $student->hsc = $request->input('hsc');
        $student->degree = $request->input('degree');
        $student->ug = $request->input('ug');
        $student->ugname = $request->input('ugname');
        $student->image =  $request->input('image');
        $student->resume = 'null';
        $student->doorno = $request->input('doorno');
        $student->street = $request->input('street');
        $student->city = $request->input('city');
        $student->state = $request->input('state');
        $student->district = $request->input('district');
        $student->pincode = $request->input('pincode');

        // if($request->file('image')){
        //     $file=$request->file('image');
        //     $filename=time().'.'.$file->getClientOriginalExtension();
        //     $request->file->move('assets/img'. $filename);
        //
        // }
        $file=$request->image;
        if($file){
            $extension=$file->getClientOriginalExtension();
            $imagename=time().'.'.$extension;
            $file->move(public_path('images/'),$imagename);
            $student->image= $imagename;
        }



        // if($request->input('resume')){
        //     $file=$request->file('resume');
        //     $extension=$file->getClientOriginalExtension();
        //     $filename=time().'.'.$extension;
        //     $file->move(public_path('/assets'),$filename);
        //     $student->resume=$file;
        // }

        $res = $student->save();

        if($res){
            return redirect('login')->with('sucess',"NOW YOU READY TO LOGIN");
        }
        else{
            return back()->with('fail',"SOMETHIG WORNG");
        }


    }

    }

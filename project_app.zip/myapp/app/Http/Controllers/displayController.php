<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class displayController extends Controller
{

    public function filter(Request $request){
        $table = DB::table('students');
        $table1 = DB::table('students')->get();
        $table2 = DB::table('filters')->get();

        if($request->name!=null){

           $table = $table->where('filters.class','like',$request->name);

        }
              $table =$table
              ->join('filters','filters.class','=','students.class')
              ->select('filters.class as class','students.name as name','students.batch as batch')
              ->get();

              return view('admin.course',['user'=>$table,'table'=>$table2]);

  }
  }



<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;

use App\Models\Student;

use App\Models\post;

use Hash;

use Session;

class CustomAuthController extends Controller
{
    public function login(){
       return view("auth.login");
    }

    public function registration(){
        return view("auth.registration");
    }

    public function registeruser(Request $request)
    {
        $request->validate([
            'email'=>'required|email|unique:users',
            'password'=>'required|min:6|max:8'
        ]);

        $user = new User();
        $user->email = $request->input('email');
        $user->password = Hash::make($request->input('password'));
        $ress = $user->save();

        if($ress){
            return redirect('students')->with('sucess','YOU HAVE REGISTER SUCESSFULLY,NOW ENTER YOUR DETAILS');
        }
        else{
            return back()->with('fail',"SOMETHIG WORNG");
        }
    }

    public function loginuser(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:6|max:8',
        ]);

        $user=User::where('email','=',$request->email)->first();
        if($user){
            if(Hash::check($request->password,$user->password)){
                $request->session()->put('loginId',$user->email);
                return redirect('/dashboard');
             }
            else{
                return back()->with('fail',"PASSWORD DOESN'T MATCH");

            }

        }
        else{
            return back()->with('fail',"EMAIL ID IS NOT REGISTER");
        }


    }

    public function dashboard(){
        $data=array();
        $datas = post::all();
        if(Session()->has('loginId')){
            $data=Student::where('email','=',Session::get('loginId'))->first();
        }
        return view('auth.dashboard',compact('data'),['datas'=>$datas]);
    }

    public function logout(){
        if(Session::has('loginId')){
            Session::pull('loginId');
            return redirect('login');
        }
    }



}


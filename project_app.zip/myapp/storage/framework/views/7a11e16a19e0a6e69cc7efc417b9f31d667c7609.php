<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Register</title>
    <link href='https://fonts.googleapis.com/css?family=Sen' rel='stylesheet'>
    <link rel="stylesheet" href="../../css/app.css">
</head>
<body>


    <nav class="header" >
        <img class="logo" src="assets\img\logo.png">
    </nav>


    <?php if(Session::has('sucess')): ?>
    <div class='alert alert-sucess success__msg'><?php echo e(Session::get('sucess')); ?></div>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <div class='alert alert-danger error__msg'><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>

<section class="container">
    <div class="box">
        <div class="login__box">

            <h2>Register</h2>
            <form  action='<?php echo e(Route('registeruser')); ?>' method="POST" >

                <?php echo csrf_field(); ?>

                <div class="form_field">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>


                <div class="form_field">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <button type="submit"  name="register">Register</button>
            </form>
            <div class="forgot">you have an account <a href = "/login">login here</a></div>
        </div>
        </div>
        </section>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/auth/registration.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/ce9c404965.js" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>

        @import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body,
        button{
            font-family: 'Poppins', sans-serif;
        }

        .header{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:  #1d3557;
            padding: 15px 10px;
        }
        .logo{
            width: 450px;
            background-color:  #1d3557;
        }

        .logout_btn {
            border: none;
            outline: none;
            padding: .7rem 16px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            background-color: crimson;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 50px;
        }
        input{
            display: flex;
            width: 330px;
            height: 40px;
            margin-top: 6px;
            padding: .8rem;
            border: 1px solid grey;
            border-radius: 5px;
            box-shadow: 1px 2px rgb(173, 173, 173);
        }
        .flex-box{
            display: flex;

        }
        .side-bar{
            height: 610px;
            width: 250px;
            background-color: rgb(60, 53, 53);
            color: white;
        }
        .side-bar h1 {
            margin: 1rem 0 2rem 0;
            font-size: 24px;
        padding-left: 25px;
        }
        .side-bar p {
            width: 250px;
            margin-bottom: 1.5rem;
            padding-left: 25px;
            padding-right: 150px;
        }
        .side-bar p:hover{
            width: 300px;
            padding: 10px 20px 10px 20px;
            background-color: rgba(49, 16, 148, 0.07);
            border: 1px solid rgba(253, 161, 161, 0.07);
            border-left: 2px solid rgb(251, 165, 165);
            color: aliceblue;
            box-shadow: 2px 2px rgba(253, 161, 161, 0.07);
            cursor: pointer;
        }

        .reg-form{
            padding: 20px 20px 0 30px;
            background-color: #e5e5e5;
            width: 100%;
            height: auto;
        }

        .reg-form h3 {
            margin-bottom: 2rem;
            text-transform: uppercase;
            font-size: 2rem;
            font-weight: 800;
            color: #2b2d42;
        }

        #cdetail{
            height: 90px;
            margin-bottom: 40px;
        }

        .btn{
            border-radius: 4px;
            border: 4px;
            width: 100px;
            padding: .8rem;
            color: white;
            background-color: #457b9d;
            cursor: pointer;
        }
        .hidden{
            display: none;
        }

    </style>
</head>
<body>


<nav class="header" >
    <img class="logo" src="assets/img/bu_logo.png">
    <a href='/login' class="logout_btn">Logout</a>
</nav>

<div class="flex-box">

    <div class="side-bar">
        <h1>Admin</h1>
        <p class="companies"  onclick="handleClickCompanies()">Companies</p>
        <p class="drive"  onclick="handleClickDrive()">Drives</p>
        <p class="course"  onclick="handleClickCourses()">Courses</p>
    </div>

    <div class="reg-form" id="companies">
        <h3>Add Drives</h3>
        <form  method="post" action="<?=url('userdata')?>">
            <div class="grid-container">
                <div>
                    <label for="cname">Company Name</label>
                    <input type="text" name="cname" id="cname" />
                </div>
                <div>
                    <label for="clocation">Location</label>
                    <input type="text"  name="clocation" id="clocation"/>
                </div>
                <div>
                    <label for="cdetail">Roles</label>
                    <input type="text" name="cdetail" id="cdetail" />
                </div>
                <div>
                    <label for="clink">Registration Link</label>
                    <input type="url"  name="clink" id="clink"/>
                </div>
                <div>
                    <label for="cdate">Last Date To Apply</label>
                    <input type="date"  name="cdate" id="cdate"/>
                </div>
                <input type="hidden" name="_token"  value="<?=csrf_token()?>">
                <div>
                    <button type="submit" class="btn">Save</button>
                </div>
            </div>
        </form>
    </div>

    <div class="reg-form hidden" id="drive">

        <form  method="GET"    action="<?=url('sam')?>">

            <div class="flex-box">


                    <table border="1" id="customers">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>COMPANY NAME</th>
                                <th>LOCATION</th>
                                <th>ROLES</th>
                                <th>REGISTRATION LINK</th>
                                <th>LAST DATE TO APPLY</th>
                            </tr>
                        </thead>

                        <tbody>


                            <?php if(!@empty($data)): ?>



                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                <td><?php echo e($i->id); ?></td>
                                <td><?php echo e($i->cname); ?></td>
                                <td><?php echo e($i->clocation); ?></td>
                                <td><?php echo e($i->cdetail); ?></td>
                                <td><?php echo e($i->clink); ?></td>
                                <td><?php echo e($i->cdate); ?></td>
                              <br>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                        </tbody>

                    </table>




                </div>
    </div>
    



 </div>

<script>
    console.log('hello');
    const companies = document.getElementById('companies');
    const drive = document.getElementById('drive');
    const course = document.getElementById('course');

    function handleClickDrive() {
        companies.classList.add("hidden");
        course.classList.add("hidden");
        drive.classList.remove("hidden");
        // drive.style.background-color = rgba(49, 16, 148, 0.07);
        console.log('clicked');
    };

    function handleClickCompanies() {
        companies.classList.remove("hidden");
        drive.classList.add("hidden");
        course.classList.add("hidden");
        console.log('clicked');
    };

    function handleClickCourses() {
        companies.classList.add("hidden");
        drive.classList.add("hidden");
        course.classList.remove("hidden");
        console.log('clicked');
    };

    // handleClickCompanies();
    // handleClickDrive();
    // companies.addEventListener("click", handleClickCompanies);

</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/admin/welcome.blade.php ENDPATH**/ ?>
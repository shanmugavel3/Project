
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/ce9c404965.js" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>

        @import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body,
        button{
            font-family: 'Poppins', sans-serif;
        }

        .header{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:  #1d3557;
            padding: 15px 10px;
        }
        .logo{
            width: 450px;
            background-color:  #1d3557;
        }

        .logout_btn {
            border: none;
            outline: none;
            padding: .7rem 16px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            background-color: crimson;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 50px;
        }
        input{
            display: flex;
            width: 330px;
            height: 40px;
            margin-top: 6px;
            padding: .8rem;
            border: 1px solid grey;
            border-radius: 5px;
            box-shadow: 1px 2px rgb(173, 173, 173);
        }
        .flex-box{
            display: flex;

        }
        .side-bar{
            height: 610px;
            width: 250px;
            background-color: rgb(60, 53, 53);
            color: white;
        }
        .side-bar h1 {
            margin: 1rem 0 2rem 0;
            font-size: 24px;
        padding-left: 25px;
        }
        .side-bar p {
            width: 250px;
            margin-bottom: 1.5rem;
            padding-left: 25px;
            padding-right: 150px;
        }
        .side-bar p:hover{
            width: 300px;
            padding: 10px 20px 10px 20px;
            background-color: rgba(49, 16, 148, 0.07);
            border: 1px solid rgba(253, 161, 161, 0.07);
            border-left: 2px solid rgb(251, 165, 165);
            color: aliceblue;
            box-shadow: 2px 2px rgba(253, 161, 161, 0.07);
            cursor: pointer;
        }

        .reg-form{
            padding: 20px 20px 0 30px;
            background-color: #e5e5e5;
            width: 100%;
            height: auto;
        }

        .reg-form h3 {
            margin-bottom: 2rem;
            text-transform: uppercase;
            font-size: 2rem;
            font-weight: 800;
            color: #2b2d42;
        }

        #cdetail{
            height: 90px;
            margin-bottom: 40px;
        }

        .btn{
            border-radius: 4px;
            border: 4px;
            width: 100px;
            padding: .8rem;
            color: white;
            background-color: #457b9d;
            cursor: pointer;
        }
        .hidden{
            display: none;
        }

    </style>
</head>
<body>


<nav class="header" >
    <img class="logo" src="assets/img/bu_logo.png">
    <a href='/login' class="logout_btn">Logout</a>
</nav>

<div class="flex-box">

    <div class="side-bar">
        <h1>Admin</h1>
        <p class="companies"  onclick="handleClickCompanies()">Companies</p>
        <p class="drive"  onclick="handleClickDrive()">Drives</p>
        <p class="course"  onclick="handleClickCourses()">Courses</p>
    </div>

    <div class="reg-form" id="companies">
        <h3>Students Course Details</h3>

        <div >
            <form  method="get" >
                <select name="name" id="name">
                    <option>Serch name</option>
                    <?php if(!empty($table)): ?>
                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->class); ?>"><?php echo e($student->class); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <button type="submit" >search</button>
            </form>
            <br>
            <table border="1">
                <tr>
                    <th>COURSE</th>
                    <th>NAME</th>
                    <th>BATCH</th>
                </tr>
                <?php if(!empty($user)): ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($users->class); ?></td>
                        <td><?php echo e($users->name); ?></td>
                        <td><?php echo e($users->batch); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </table>
        </div>
    </div>
 </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/admin/filter.blade.php ENDPATH**/ ?>
<h1> hey<?php echo e($name); ?>,
Can your Laravel app send emails yet?
Funny Coder
</h1>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/email/test-email.blade.php ENDPATH**/ ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>Register</title>
    <link href='https://fonts.googleapis.com/css?family=Sen' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>


    <nav class="header">
        <img  class='logo'  src="assets/img/bu_logo.png">

    </nav>


    <?php if(Session::has('sucess')): ?>
    <div class='alert alert-sucess success__msg'><?php echo e(Session::get('sucess')); ?></div>
     <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <div class='alert alert-danger error__msg'><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>

<section class="container">
    <div class="box">
        <div class="login__box">

            <h2>Register</h2>
            <form action='<?php echo e(Route('registerdetails')); ?>' method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form_field">
                    <label for="name"><b> NAME </b></label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="gender"><b>GENDER</b></label>
                    <label for="male">
                    <input type="radio" id="male" name="gender" value="male" seleted>
                    MALE </label>
                    <label for="female">
                    <input type="radio" id="female" name="gender" value="female">
                    FEMALE </label>
                    <span class="text-danger"><?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>


                <div class="form_field">
                    <label for="regno"><b>REGNO</b></label>
                    <input type="text" name="regno" id="regno" value="<?php echo e(old('regno')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['regno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="class"><b>CLASS</b></label>
                    <input type="text" name="class" id="class" list="classes" value="<?php echo e(old('class')); ?>">
                    <datalist id="classes"> 
                        <option value="I MCA"></option>
                        <option value="II MCA"></option>
                        <option value="I CYBER SECURITY"></option>
                        <option value="II CYBER SECURITY"></option>
                    </datalist>
                    <span class="text-danger"><?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="batch"><b>BATCH</b></label>
                    <input type="text" name="batch" id="batch" placeholder="2021-2023" value="<?php echo e(old('batch')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['batch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>


                <div class="form_field">
                    <label for="email"><b>EMAIL</b></label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="dob"><b>DOB</b></label>
                    <input type="date" name="dob" id="dob" value="<?php echo e(old('dob')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="phnno"><b>MOBILE NO</b></label>
                    <input type="tel" name="phnno" id="phnno"  value="<?php echo e(old('phnno')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['phnno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div>ADDRESS:
                    <div class="form_field">
                    <label for="doorno"><b>DOORNO</b></label>
                    <input type="text" name="doorno" id="doorno" value="<?php echo e(old('doorno')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['doorno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>

                <div class="form_field">
                    <label for="street">STREET</label>
                    <input type="text" name="street" id="street" value="<?php echo e(old('street')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="city">CITY</label>
                    <input type="text" name="city" id="city" value="<?php echo e(old('city')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="district">DISTRICT</label>
                    <input type="text" name="district" id="district" list="districts" value="<?php echo e(old('district')); ?>">
                    <datalist id="districts">
                        <option value="THENI"></option>
                        <option value="MADURAI"></option>
                        <option value="COIMBATORE"></option>
                    </datalist>
                    <span class="text-danger"><?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="pincode">PINCODE</label>
                    <input type="text" name="pincode" id="pincode" value="<?php echo e(old('pincode')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="state">STATE</label>
                    <input type="text" name="state" list="states" id="state" value="<?php echo e(old('state')); ?>">
                    <datalist id="states">
                        <option value="TAMILNADU"></option>
                        <option value="KERELA"></option>
                        <option value="KARNATAKA"></option>
                    </datalist>
                    <span class="text-danger"><?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                </div>


                <div class="form_field">
                    <label for="sslcname">SSLC SCHOOL</label>
                    <input type="text" name="sslcname" id="sslcname" value="<?php echo e(old('sslcname')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['sslcname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>


                <div class="form_field">
                    <label for="sslc">SSLC SCORE IN %</label>
                    <input type="text" name="sslc" pattern="[0-9]{2}" placeholder="90" id="sslc" value="<?php echo e(old('sslc')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['sslc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="hsc">HSC SCHOOL</label>
                    <input type="text" name="hscname" id="hsc" value="<?php echo e(old('hscname')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['hscname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="hsc">HSC SCORE IN %</label>
                    <input type="text" name="hsc" pattern="[0-9]{2}" placeholder="90" id="hsc" value="<?php echo e(old('hsc')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['hsc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="degree">UG DEGREE</label>
                    <input type="text" name="degree" id="degree" value="<?php echo e(old('degree')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['degree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="ug">UG COLLEGE</label>
                    <input type="text" name="ugname" id="ugname" value="<?php echo e(old('ug')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['ug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form_field">
                    <label for="ug">UG SCORE IN %</label>
                    <input type="text" name="ug" pattern="[0-9]{2}" placeholder="90" id="hsc" value="<?php echo e(old('ug')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['ug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div>
                    <label for="image">UPLOAD YOUR IMAGE: </label>
                    <input type="file" fi name="image" id="image" value="<?php echo e(old('image')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>
                <br>

                <div>
                    <label for="resume">UPLOAD YOUR RESUME: </label>
                    <input type="file" name="resume" id="resume" value="<?php echo e(old('resume')); ?>">
                    <span class="text-danger"><?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>
                <br>


                <button type="submit" name="register">Register</button>

                <div class="auth__link">
                    you have an account! <a href="\login">login here.</a>
                   </div>



            </form>
        </div>
        </div>
        </section>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/student/index.blade.php ENDPATH**/ ?>
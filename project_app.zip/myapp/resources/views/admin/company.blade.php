<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>

        @import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body,
        button{
            font-family: 'Poppins', sans-serif;
        }

        .header{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:  #0f1930;
            padding: 1rem 10px;
        }
        .logo{
            width: 450px;
            background-color:  #0f1930;
        }

        .logout_btn {
            border: none;
            outline: none;
            padding: .4rem 16px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            font-size: 14px;
            background-color: crimson;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 50px;
        }
        input{
            display: flex;
            width: 330px;
            height: 40px;
            margin-top: 6px;
            padding: .8rem;
            border: 1px solid grey;
            border-radius: 5px;
            box-shadow: 1px 2px rgb(173, 173, 173);
        }
        .flex-box{
            display: flex;

        }
        .side-bar{
            height: 610px;
            width: 350px;
            background-color: #2e2f2f;
        }
        .side-bar img {
            width: 20px;
            height: 20px;
            margin-right: 10px;
        }
        .side-bar h1 {
            margin: 1rem 0 2rem 40px;
            font-size: 20px;
            color: #e07a5f;
            letter-spacing: 9px;
            text-transform: uppercase
        }
        .side-bar a {
            display: flex;
            align-items: center;
            color: #fff;
            text-decoration: none;
            width: 100%;
            margin-bottom: 1rem;
            padding: 10px 0px 10px 40px;
        }
        .side-bar a:hover{
            width: 100%;
            color: #e07a5f;
            cursor: pointer;
        }

        .reg-form{
            padding: 20px 20px 0 30px;
            background-color: #e5e5e5;
            width: 100%;
            height: auto;
        }

        .reg-form h3 {
            margin-bottom: 2rem;
            text-transform: uppercase;
            font-size: 2rem;
            font-weight: 800;
            color: #2b2d42;
        }

        #cdetail{
            height: 90px;
            margin-bottom: 40px;
        }

        .btn{
            border-radius: 4px;
            border: 4px;
            width: 100px;
            padding: .8rem;
            color: white;
            background-color: #2d3142;
            cursor: pointer;
        }

    </style>

</head>
<body>


    <nav class="header" >
        <img class="logo" src="assets/img/bu_logo.png">
        <a href='/login' class="logout_btn">Logout</a>
    </nav>


    <div class="flex-box">

        <div class="side-bar">
            <h1>Admin</h1>
            <a href="/company">
                <img src="assets/icon/companies.png" alt="companies">
                Company
            </a>
            <a href="/drive">
                <img src="assets/icon/drives.png" alt="">Drive
            </a>
            <a href="/course" class="">
                <img src="assets/icon/light.png" alt="">Course
            </a>

            <a href="/fullcalender" class="">
                <img src="assets/icon/notification.png" alt="">Event
            </a>
        </div>


        <div class="reg-form">
            <h3>Add Drives</h3>
            <form  method="post" action="<?=url('drive')?>">
                <div class="grid-container">
                    <div>
                        <label for="cname">Company Name</label>
                        <input type="text" name="cname" id="cname" />
                    </div>
                    <div>
                        <label for="clocation">Location</label>
                        <input type="text"  name="clocation" id="clocation"/>
                    </div>
                    <div>
                        <label for="cdetail">Roles</label>
                        <input type="text" name="cdetail" id="cdetail" />
                    </div>
                    <div>
                        <label for="clink">Registration Link</label>
                        <input type="url"  name="clink" id="clink"/>
                    </div>
                    <div>
                        <label for="cdate">Last Date To Apply</label>
                        <input type="date"  name="cdate" id="cdate"/>
                    </div>
                    <input type="hidden" name="_token"  value="<?=csrf_token()?>">
                    <div>
                        <button type="submit" class="btn">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


</body>
</html>



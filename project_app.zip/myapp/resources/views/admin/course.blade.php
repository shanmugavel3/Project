<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>

        @import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body,
        button{
            font-family: 'Poppins', sans-serif;
        }

        .header{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:  #0f1930;
            padding: 1rem 10px;
        }
        .logo{
            width: 450px;
            background-color:  #0f1930;
        }

        .logout_btn {
            border: none;
            outline: none;
            padding: .4rem 16px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            font-size: 14px;
            background-color: crimson;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 50px;
        }
        input{
            display: flex;
            width: 330px;
            height: 40px;
            margin-top: 6px;
            padding: .8rem;
            border: 1px solid grey;
            border-radius: 5px;
            box-shadow: 1px 2px rgb(173, 173, 173);
        }
        .flex-box{
            display: flex;

        }
        .side-bar{
            height: 610px;
            width: 350px;
            background-color: #2e2f2f;
        }

        .side-bar img {
            width: 20px;
            height: 20px;
            margin-right: 10px;
        }
        .side-bar h1 {
            margin: 1rem 0 2rem 40px;
            font-size: 20px;
            color: #e07a5f;
            letter-spacing: 9px;
            text-transform: uppercase
        }
        .side-bar a {
            display: flex;
            align-items: center;
            color: #fff;
            text-decoration: none;
            width: 100%;
            margin-bottom: 1rem;
            padding: 10px 0px 10px 40px;
        }
        .side-bar a:hover{
            width: 100%;
            color: #e07a5f;
            cursor: pointer;
        }

        .customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td, .customers th {
            border: 1px solid #ddd;
            padding: 8px;

        }

        .customers tr:nth-child(even){
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            color: #fff;
            background-color: #2E2F2F;
        }
        .course__container{
            width: 100%;
            margin: 3rem 2rem;
        }

        .course__form{
            width: 100%;
            margin-bottom: 3rem;
        }

        .course__select {
            border: 2px solid #000;
            padding: 10px;
            border-radius:5px;
            font-size: 15px;
        }

        .course__select option{
            padding: 10px;
        }

        .course__form button {
            padding: 12px 2rem;
            border-radius: 5px;
            outline: none;
            border: none;
            cursor: pointer;
            background: #8d99ae;
            color: #000;
            font-weight: 600;
        }

    </style>
</head>
<body>

    <nav class="header" >
        <img class="logo" src="assets/img/bu_logo.png">
        <a href='/login' class="logout_btn">Logout</a>
    </nav>


    <div class="flex-box">

        <div class="side-bar">
            <h1>Admin</h1>
            <a href="/company">
                <img src="assets/icon/companies.png" alt="companies">
                Company
            </a>
            <a href="/drive">
                <img src="assets/icon/drives.png" alt="">Drive
            </a>
            <a href="/course" class="">
                <img src="assets/icon/light.png" alt="">Course
            </a>
            <a href="/fullcalender" class="">
                <img src="assets/icon/notification.png" alt="">Event
            </a>
        </div>

        <div class="course__container">

            <form  method="get" class="course__form">
                <select name="name" id="name" class="course__select">
                    <option>Department</option>
                    @if(!empty($table))
                    @foreach ($table as $student)
                    <option value="{{ $student->class }}">{{ $student->class}}</option>
                    @endforeach
                    @endif
                </select>
                <button type="submit" >search</button>
            </form>

            <table class='customers'>
                <thead>
                    <tr>
                        <th>COURSE</th>
                        <th>NAME</th>
                        <th>BATCH</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($user))
                        @foreach ($user as $users)
                            <tr>
                                <td>{{ $users->class }}</td>
                                <td>{{ $users->name }}</td>
                                <td>{{$users->batch }}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="3">No Records Found</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>

    </div>

</body>
</html>



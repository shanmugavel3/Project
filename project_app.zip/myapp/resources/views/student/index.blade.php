<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>Register</title>
    <link href='https://fonts.googleapis.com/css?family=Sen' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>


    <nav class="header">
        <img  class='logo'  src="assets/img/bu_logo.png">

    </nav>


    @if (Session::has('sucess'))
    <div class='alert alert-sucess success__msg'>{{Session::get('sucess')}}</div>
     @endif
    @if (Session::has('fail'))
        <div class='alert alert-danger error__msg'>{{Session::get('fail')}}</div>
        @endif

<section class="container">
    <div class="box">
        <div class="login__box">

            <h2>Register</h2>
            <form action='{{Route('registerdetails')}}' method="POST" enctype="multipart/form-data">
                @csrf

                <div class="form_field">
                    <label for="name"><b> NAME </b></label>
                    <input type="text" name="name" id="name" value="{{old('name')}}">
                    <span class="text-danger">@error('name'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="gender"><b>GENDER</b></label>
                    <label for="male">
                    <input type="radio" id="male" name="gender" value="male" seleted>
                    MALE </label>
                    <label for="female">
                    <input type="radio" id="female" name="gender" value="female">
                    FEMALE </label>
                    <span class="text-danger">@error('gender'){{$message}} @enderror</span>
                </div>


                <div class="form_field">
                    <label for="regno"><b>REGNO</b></label>
                    <input type="text" name="regno" id="regno" value="{{old('regno')}}">
                    <span class="text-danger">@error('regno'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="class"><b>CLASS</b></label>
                    <input type="text" name="class" id="class" list="classes" value="{{old('class')}}">
                    <datalist id="classes"> 
                        <option value="I MCA"></option>
                        <option value="II MCA"></option>
                        <option value="I CYBER SECURITY"></option>
                        <option value="II CYBER SECURITY"></option>
                    </datalist>
                    <span class="text-danger">@error('class'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="batch"><b>BATCH</b></label>
                    <input type="text" name="batch" id="batch" placeholder="2021-2023" value="{{old('batch')}}">
                    <span class="text-danger">@error('batch'){{$message}} @enderror</span>
                </div>


                <div class="form_field">
                    <label for="email"><b>EMAIL</b></label>
                    <input type="email" name="email" id="email" value="{{old('email')}}">
                    <span class="text-danger">@error('email'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="dob"><b>DOB</b></label>
                    <input type="date" name="dob" id="dob" value="{{old('dob')}}">
                    <span class="text-danger">@error('dob'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="phnno"><b>MOBILE NO</b></label>
                    <input type="tel" name="phnno" id="phnno"  value="{{old('phnno')}}">
                    <span class="text-danger">@error('phnno'){{$message}} @enderror</span>
                </div>

                <div>ADDRESS:
                    <div class="form_field">
                    <label for="doorno"><b>DOORNO</b></label>
                    <input type="text" name="doorno" id="doorno" value="{{old('doorno')}}">
                    <span class="text-danger">@error('doorno'){{$message}} @enderror</span>
                    </div>

                <div class="form_field">
                    <label for="street">STREET</label>
                    <input type="text" name="street" id="street" value="{{old('street')}}">
                    <span class="text-danger">@error('street'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="city">CITY</label>
                    <input type="text" name="city" id="city" value="{{old('city')}}">
                    <span class="text-danger">@error('city'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="district">DISTRICT</label>
                    <input type="text" name="district" id="district" list="districts" value="{{old('district')}}">
                    <datalist id="districts">
                        <option value="THENI"></option>
                        <option value="MADURAI"></option>
                        <option value="COIMBATORE"></option>
                    </datalist>
                    <span class="text-danger">@error('district'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="pincode">PINCODE</label>
                    <input type="text" name="pincode" id="pincode" value="{{old('pincode')}}">
                    <span class="text-danger">@error('pincode'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="state">STATE</label>
                    <input type="text" name="state" list="states" id="state" value="{{old('state')}}">
                    <datalist id="states">
                        <option value="TAMILNADU"></option>
                        <option value="KERELA"></option>
                        <option value="KARNATAKA"></option>
                    </datalist>
                    <span class="text-danger">@error('state'){{$message}} @enderror</span>
                </div>

                </div>


                <div class="form_field">
                    <label for="sslcname">SSLC SCHOOL</label>
                    <input type="text" name="sslcname" id="sslcname" value="{{old('sslcname')}}">
                    <span class="text-danger">@error('sslcname'){{$message}} @enderror</span>
                </div>


                <div class="form_field">
                    <label for="sslc">SSLC SCORE IN %</label>
                    <input type="text" name="sslc" pattern="[0-9]{2}" placeholder="90" id="sslc" value="{{old('sslc')}}">
                    <span class="text-danger">@error('sslc'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="hsc">HSC SCHOOL</label>
                    <input type="text" name="hscname" id="hsc" value="{{old('hscname')}}">
                    <span class="text-danger">@error('hscname'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="hsc">HSC SCORE IN %</label>
                    <input type="text" name="hsc" pattern="[0-9]{2}" placeholder="90" id="hsc" value="{{old('hsc')}}">
                    <span class="text-danger">@error('hsc'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="degree">UG DEGREE</label>
                    <input type="text" name="degree" id="degree" value="{{old('degree')}}">
                    <span class="text-danger">@error('degree'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="ug">UG COLLEGE</label>
                    <input type="text" name="ugname" id="ugname" value="{{old('ug')}}">
                    <span class="text-danger">@error('ug'){{$message}} @enderror</span>
                </div>

                <div class="form_field">
                    <label for="ug">UG SCORE IN %</label>
                    <input type="text" name="ug" pattern="[0-9]{2}" placeholder="90" id="hsc" value="{{old('ug')}}">
                    <span class="text-danger">@error('ug'){{$message}} @enderror</span>
                </div>

                <div>
                    <label for="image">UPLOAD YOUR IMAGE: </label>
                    <input type="file" fi name="image" id="image" value="{{old('image')}}">
                    <span class="text-danger">@error('image'){{$message}} @enderror</span>
                </div>
                <br>

                <div>
                    <label for="resume">UPLOAD YOUR RESUME: </label>
                    <input type="file" name="resume" id="resume" value="{{old('resume')}}">
                    <span class="text-danger">@error('resume'){{$message}} @enderror</span>
                </div>
                <br>


                <button type="submit" name="register">Register</button>

                <div class="auth__link">
                    you have an account! <a href="\login">login here.</a>
                   </div>



            </form>
        </div>
        </div>
        </section>
</body>
</html>

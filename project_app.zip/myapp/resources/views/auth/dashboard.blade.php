<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/ce9c404965.js" crossorigin="anonymous"></script>
    <link href='https://fonts.googleapis.com/css?family=Sen' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <style>
    .side_bar a{
        display: flex;
        align-items: center;
        color: #fff;
        text-decoration: none;
        width: 100%;
        margin-bottom: 1rem;
        padding: 10px 0px 10px 40px;
    }
    .calendar{
        text-decoration: none;
        color: #000;
    }
    .calendar:hover{
        color: #fff;
    }
</style>

</head>
<body>

    <nav class="header" >
        <img class="logo" src="assets\img\logo.png">
        <a href='/login' class="logout_btn">Logout</a>
    </nav>
    {{-- class="flex-box" class="cotent-margin" --}}
    <div class="container">

        <div class="left__side">
            <button class="profile"  onclick="handleClickProfile()"><i class="fas fa-user-graduate"></i> PROFILE</button>
            <button class="drives" onclick="handleClickDrive()"><i class="fas fa-search"></i> DRIVE</button>
            <button class="events">
                <a href="/fullcalender" class="side_bar calendar">
                    <i class="fas fa-calendar-alt" ></i>EVENT
                </a></button>
        </div>

        <div class="right__side">

         <div id="profile"  class="profile">
            <div class="profile__img">
                <img src="{{asset('images/'.$data->image)}}">
            </div>

            <div class="grid__container">
                <div class="grig__box">
                    <div class="personal__details">
                        <h2>PERSONAL DETAILS</h2>
                        <p>Name : <span>{{$data->name}}</span></p>
                        <p>Mail : <span>{{$data->email}}</span></p>
                        <p>MOBILE NUMBER: <span>{{$data->phnno}}</span></p>
                        <p>DATE OF BIRTH : <span>{{$data->dob}}</span></p>
                    <p>GENDER : <span>{{$data->gender}}</span></p>
                    </div>
                    <div class="pg__details">
                        <h2>PG DETAILS</h2>
                        <p>REGISTER NO: : <span>{{$data->regno}}</span></p>
                        <p>CLASS :  <span>{{$data->class}}</span></p>
                        <p>BATCH :<span>{{$data->batch}}</span></p>
                    </div>
                    <div class="ug__details">
                        <h2>UG DETAILS</h2>
                        <p>UG DEGREE : <span>{{$data->degree}}</span></p>
                        <p>UG COLLEGE : <span>{{$data->ugname}}</span></p>
                        <p>UG SCORE IN % : <span>{{$data->ug}}</span></p>
                    </div>
                    <div class="school__details">
                        <h2>SCHOOL DETAILS</h2>
                        <p>SSLC SCHOOL : <span>{{$data->sslcname}}</span></p>
                        <p>SSLC SCORE IN %: <span>{{$data->sslc}}</span></p>
                        <p>HSC SCHOOL : <span>{{$data->hscname}}</span></p>
                        <p>HSC SCORE IN %: <span>{{$data->hsc}}</span></p>
                    </div>
                    <div class="location__details">
                        <h2>LOCATION DETAILS</h2>
                        <p>DOOR NO : <span>{{$data->doorno}}</span></p>
                        <p>STREET : <span>{{$data->street}}</span></p>
                        <p>CITY : <span>{{$data->city}}</span></p>
                        <p>DISTRICT : <span>{{$data->district}}</span></p>
                        <p>STATE : <span>{{$data->state}}</span></p>
                        <p>PINCODE : <span>{{$data->pincode}}</span></p>
                    </div>
                </div>
            </div>
            </div>

            <div id='drives' class="drive  hidden">

                <form  method="GET"    action="<?=url('userdata')?>">



                    <div class="grid__container">

                        <h2 style="color:rgb(4, 250, 41)"> UPCOMING DRIVES </h2>
                        <div class="grig__box">
                            @foreach($datas as $i )
                            <div class="personal__details">

                                <h2>COMPANY DETAILS</h2>
                                <p>COMPANY NAME : <span>{{$i->cname}}</span></p>
                                <p>LOCATION : <span>{{$i->clocation}}</span></p>
                                <p>ROLE: <span>{{$i->cdetail}}</span></p>
                                <p>REGISTRATION LINK : <span><a href = "{{$i->	clink}}">{{$i->	clink}}</a></span></p>
                                <p>LAST DATE TO APPLY: <span>{{$i->cdate }}</span></p>
                            </div>
                            @endforeach
                        </div>
                    </div>


                    </div>


        </div>








    </div>

    <script>

        const profiles = document.getElementById('profile');
        const drive = document.getElementById('drives');

        function handleClickProfile() {
            drive.classList.add("hidden");
            profiles.classList.remove("hidden");

        };

        function handleClickDrive() {
            profiles.classList.add("hidden");
            drive.classList.remove("hidden");

        };




    </script>





</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>login</title>
    <link href='https://fonts.googleapis.com/css?family=Sen' rel='stylesheet'>

</head>
<body>


    <nav class="header" >
        <img class="logo" src="assets\img\logo.png">
    </nav>

    @if (Session::has('sucess'))
    <div class='alert alert-sucess success__msg'>{{Session::get('sucess')}}</div>
    @endif
    @if (Session::has('fail'))
        <div class='alert alert-danger error__msg'>{{Session::get('fail')}}</div>
    @endif

    <div class="container">
        <div class="flex__box">
            <div class="login__box">
                <h2>login</h2>

                <form method="POST"  action='{{Route('loginuser')}}'>
                    @csrf
                    <div class="form_field">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" value="{{old('email')}}">
                        <span class="text-danger">@error('email'){{$message}} @enderror</span>
                    </div>
                    <div class="form_field">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" value="{{old('password')}}" >
                        <span class="text-danger">@error('password'){{$message}} @enderror</span>
                    </div>
                    <button type="submit" name="login">LOGIN</button>
                    <div class="forgot">you don't have an account <a href = "/registration">register here</a></div>


                </form>
            </div>
            <div class="img__box">
                <img src="assets/img/proj1.png" alt="img">
            </div>
        </div>
    </div>

</body>
</html>

<h1> hey{{$name}},
Can your Laravel app send emails yet?
Funny Coder
</h1>
